# Matching Game
 Memory-based games created by javascript has a grid of 4x4 cards contain different pairs of icons.

## How to open the game

Open the index.html file by any browser that supports html5.

## How to play?
1. Click on any two cards.
2. If the two cards match --> will pin it on the deck
3. If they don't match --> will  be  face down  
4. keep in your memory what was on each card and where it was.
5. The player win when all cards are matched 

In the end  display a dialog box show the time and  number of stars you got it to complete the game.

### **Note :**

The rating of player depend on the **number of moves** to show all matched cards.

- 1-10  moves you will get 3 stars.
- 11-18 moves you will get 2 stars.
- from 19 to up you will get only one star.

# Dependencies
   * Font Awsome.js 



